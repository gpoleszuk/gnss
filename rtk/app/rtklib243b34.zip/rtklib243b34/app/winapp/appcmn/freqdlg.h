//---------------------------------------------------------------------------

#ifndef freqdlgH
#define freqdlgH
//---------------------------------------------------------------------------
#include <System.Classes.hpp>
#include <Vcl.Controls.hpp>
#include <Vcl.StdCtrls.hpp>
#include <Vcl.Forms.hpp>
#include <Vcl.ExtCtrls.hpp>
//---------------------------------------------------------------------------
class TFreqDialog : public TForm
{
__published:
	TButton *BtnOk;
	TPanel *Panel1;
	TPanel *Panel2;
	TLabel *Label3;
	TPanel *Panel3;
	TLabel *Label5;
	TPanel *Panel4;
	TLabel *Label7;
	TPanel *Panel5;
	TLabel *Label9;
	TPanel *Panel6;
	TLabel *Label11;
	TPanel *Panel7;
	TPanel *Panel8;
	TLabel *Label1;
	TPanel *Panel9;
	TLabel *Label14;
	TPanel *Panel10;
	TPanel *Panel11;
	TPanel *Panel12;
	TPanel *Panel13;
	TPanel *Panel14;
	TPanel *Panel15;
	TPanel *Panel16;
	TPanel *Panel17;
	TPanel *Panel18;
	TPanel *Panel19;
	TPanel *Panel20;
	TPanel *Panel21;
	TPanel *Panel22;
	TPanel *Panel23;
	TPanel *Panel24;
	TPanel *Panel25;
	TPanel *Panel26;
	TPanel *Panel27;
	TPanel *Panel28;
	TPanel *Panel29;
	TPanel *Panel30;
	TPanel *Panel31;
	TPanel *Panel32;
	TPanel *Panel33;
	TPanel *Panel34;
	TPanel *Panel35;
	TPanel *Panel36;
	TPanel *Panel37;
	TPanel *Panel38;
	TPanel *Panel39;
	TPanel *Panel45;
	TPanel *Panel46;
	TPanel *Panel47;
	TPanel *Panel48;
	TPanel *Panel49;
	TPanel *Panel50;
	TPanel *Panel51;
	TPanel *Panel52;
	TPanel *Panel53;
	TPanel *Panel54;
private:
public:
	__fastcall TFreqDialog(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TFreqDialog *FreqDialog;
//---------------------------------------------------------------------------
#endif
